import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PostDetailComponent } from './components/post-detail/post-detail.component';
import { CreatePostComponent } from './components/create-post/create-post.component';
import { ListPostsComponent } from './components/list-posts/list-posts.component';

const routes: Routes = [
  {path:'postList', component: ListPostsComponent},
  {path:'postDetail', component: PostDetailComponent},
  {path:'createPost', component: CreatePostComponent},
  {path:'',redirectTo:'/postList', pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
