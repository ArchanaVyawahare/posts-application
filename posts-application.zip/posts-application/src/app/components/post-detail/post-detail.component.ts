import { Component, OnInit } from '@angular/core';
import { PostsService } from 'src/app/posts.service';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { Post } from 'src/post';
import { PostComment } from 'src/comment';

@Component({
  selector: 'app-post-detail',
  templateUrl: './post-detail.component.html',
  styleUrls: ['./post-detail.component.css']
})
export class PostDetailComponent implements OnInit {
  selectedPostId : number;
  selectedPost : Post={userId:"",id:null,title:"",body:""};
  selectedPostComment : PostComment[];
  constructor(private postService : PostsService,private activatedRouter : ActivatedRoute,private router : Router) { }

  ngOnInit() {
    this.activatedRouter.queryParams.subscribe(param=>{
         this.selectedPostId = param["id"];
         console.log("selected Post Id is : "+this.selectedPostId);
    });

    this.getPostById();
    this.getPostCommentById();
  }

  getPostById(){
    this.postService.fetchPostById(this.selectedPostId).subscribe((data : Post) =>{
         this.selectedPost = data;
         console.log("Selected Post Details : ",this.selectedPost);
    });
  }
  getPostCommentById() { 
    this.postService.fetchCommentById(this.selectedPostId).subscribe((data : PostComment[])=>{
       this.selectedPostComment = data;
       console.log("Selected Post comment is : ", this.selectedPostComment);
    });
  }

  updatePost(){
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "userId": this.selectedPost.userId,
          "id" : this.selectedPost.id,
          "title":this.selectedPost.title,
          "body":this.selectedPost.body
      }
  };
  console.log("selected post for update is:  ",navigationExtras);
  this.router.navigate(["createPost"], navigationExtras);
   
  }

}
