import { Component, OnInit } from '@angular/core';
import { PostsService } from 'src/app/posts.service';
import { Post } from 'src/post';
import { NavigationExtras, Router } from '@angular/router';

@Component({
  selector: 'app-list-posts',
  templateUrl: './list-posts.component.html',
  styleUrls: ['./list-posts.component.css']
})
export class ListPostsComponent implements OnInit {
  postList : Post[];
  constructor(private postService : PostsService,private router : Router) { }

  ngOnInit() {
    this.getPostList();
  }

   getPostList() {
      this.postService.fetchPostsList().subscribe((data:Post[])=>{
        console.log(data);
        this.postList = data;
      })
   }

   getPostDetail(item : Post) {
    let navigationExtras: NavigationExtras = {
      queryParams: {
          "id": item.id
      }
  };
  this.router.navigate(["postDetail"], navigationExtras);

   }

}
