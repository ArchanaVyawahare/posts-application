import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Post } from 'src/post';
import { PostsService } from 'src/app/posts.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrls: ['./create-post.component.css']
})
export class CreatePostComponent implements OnInit {

  postObject : Post = {userId:"",id:null,title:"",body:""};
  createPostForm:FormGroup;
  submitted = false;
  isupdatedPost = false;
  constructor(private formBuidler : FormBuilder,private postService : PostsService,private activatedRouter :ActivatedRoute) { }

  ngOnInit() {
    this.postObject  = {userId:"",id:null,title:"",body:""};
    this.activatedRouter.queryParams.subscribe(param=>{
      if(param["id"] != null && param["id"] != undefined) {
        this.postObject.userId = param["userId"];
        this.postObject.id = param["id"];
        this.postObject.title = param["title"];
        this.postObject.body = param["body"];
        this.isupdatedPost = true;
        console.log("It is call for Update post..");
      }
      console.log("Post to update is : ",this.postObject);
 });
    
   this.createPostForm = this.formBuidler.group({
    userId:['',[Validators.required]],
     title:['',[Validators.required]],
     body:['',Validators.required]
   });

  }

  get f() { return this.createPostForm.controls; }

  createPost(item : Post){
    this.submitted = true;
          if (this.createPostForm.invalid) {
              return;
          }
 if(this.isupdatedPost) { 
  this.postService.updatePost(this.postObject,this.postObject.id).subscribe(data =>{
    console.log("Update successfully",data);
    if(data) {
      alert("Post updated successfully");
    }
    
  });
 } else {
    this.postService.createPost(item).subscribe(data=>{
      console.log("Result of Post method is : ",data);
      if(data) {
        alert("Post Created Successfully");
      }
    });
  }
  }

}
