export class Post {
    userId : string;
    id : number;
    title : string;
    body : string;
}